 <?php
 $dbhost = 'localhost'; 
   $dbuser = '968907'; 
   $dbpass = '9857473359'; 
   $conn = mysql_connect($dbhost, $dbuser, $dbpass);
   ?>