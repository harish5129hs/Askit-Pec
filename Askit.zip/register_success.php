<?php 
echo 'registered successfully';
?>